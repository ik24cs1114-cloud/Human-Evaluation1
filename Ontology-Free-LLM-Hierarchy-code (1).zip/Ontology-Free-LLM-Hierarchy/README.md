# Ontology-Free LLM Hierarchy

Code and reproducibility materials for the LLM-QTH cross-domain human evaluation.

Place the six anonymized A1/A2/A3 CSV files in `data/human_evaluation/`.

Run:

```bash
pip install -r requirements.txt
python src/human_validation.py
python src/cross_domain_figure.py
```
