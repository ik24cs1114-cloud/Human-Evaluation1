from pathlib import Path
import matplotlib.pyplot as plt
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
FIGURES_DIR = ROOT / "figures"
FIGURES_DIR.mkdir(parents=True, exist_ok=True)

measures = [
    "Topic relevance",
    "Coherence",
    "Level appropriateness",
    "Progression",
    "Non-redundancy",
]
mmlu = np.array([2.437, 2.733, 2.533, 2.720, 2.413])
medmcqa = np.array([2.492, 2.653, 2.693, 2.573, 2.467])

x = np.arange(len(measures))
width = 0.36

fig, ax = plt.subplots(figsize=(9, 5.5))
bars1 = ax.bar(x - width/2, mmlu, width, label="MMLU")
bars2 = ax.bar(x + width/2, medmcqa, width, label="MedMCQA")

ax.set_ylabel("Mean human rating (0–3)")
ax.set_xticks(x)
ax.set_xticklabels(measures, rotation=15, ha="right")
ax.set_ylim(0, 3.2)
ax.legend()
ax.grid(axis="y", alpha=0.25)

for bars in (bars1, bars2):
    for bar in bars:
        h = bar.get_height()
        ax.text(bar.get_x() + bar.get_width()/2, h + 0.04, f"{h:.2f}",
                ha="center", va="bottom", fontsize=9)

fig.tight_layout()
fig.savefig(FIGURES_DIR / "cross_domain_human_evaluation.png", dpi=300, bbox_inches="tight")
fig.savefig(FIGURES_DIR / "cross_domain_human_evaluation.pdf", bbox_inches="tight")
print("Figure files saved in:", FIGURES_DIR)
