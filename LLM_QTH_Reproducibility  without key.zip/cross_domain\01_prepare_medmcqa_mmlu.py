import json
import random
import re
import pandas as pd
from datasets import load_dataset

from config import DATA_DIR, SEED, MEDMCQA_N, MMLU_PER_SUBJECT, MMLU_SUBJECTS


def clean_text(x):
    if x is None:
        return ""
    return re.sub(r"\s+", " ", str(x)).strip()


def norm_text(x):
    return clean_text(x).lower()


def save_records(records, stem):
    df = pd.DataFrame(records)
    csv_path = DATA_DIR / f"{stem}.csv"
    json_path = DATA_DIR / f"{stem}.json"
    df.to_csv(csv_path, index=False, encoding="utf-8")
    with open(json_path, "w", encoding="utf-8") as f:
        json.dump(records, f, indent=2, ensure_ascii=False)
    print(f"Saved: {csv_path}")
    print(f"Saved: {json_path}")


def count_unique_topics(split_name):
    ds = load_dataset("openlifescienceai/medmcqa", split=split_name)
    topics = []
    for item in ds:
        t = clean_text(item.get("topic_name"))
        if t:
            topics.append(norm_text(t))
    return len(set(topics))


def prepare_medmcqa():
    print("\n[1/2] Preparing MedMCQA...")

    # IMPORTANT:
    # In the current HF distribution, validation contains too few unique
    # non-empty topic_name values for a 100-topic sample. The whole dataset
    # has thousands of topics, concentrated mainly in train.
    #
    # We are NOT training LLM-QTH on MedMCQA. We use the train split only
    # as an external SOURCE POOL of topic labels for zero-shot evaluation.
    split_name = "train"
    print(f"Using MedMCQA source pool: {split_name}")

    ds = load_dataset("openlifescienceai/medmcqa", split=split_name)

    rows = []
    seen = set()

    for item in ds:
        topic = clean_text(item.get("topic_name"))
        subject = clean_text(item.get("subject_name"))

        if not topic or not subject:
            continue

        key = norm_text(topic)
        if key in seen:
            continue
        seen.add(key)

        rows.append({
            "source_dataset": "MedMCQA",
            "domain": "Medical Education",
            "subject": subject,
            "query": topic,
            "source_split": split_name,
            "source_field": "topic_name",
            "original_id": clean_text(item.get("id")),
        })

    print(f"Unique non-empty MedMCQA topic_name values in {split_name}: {len(rows)}")

    if len(rows) < MEDMCQA_N:
        raise RuntimeError(
            f"Only {len(rows)} unique topic_name values in MedMCQA {split_name}; "
            f"need {MEDMCQA_N}."
        )

    # Round-robin sampling across subjects to improve medical-subject coverage.
    df = pd.DataFrame(rows)
    groups = {}
    for subject, group in df.groupby("subject"):
        groups[subject] = (
            group.sample(frac=1, random_state=SEED).to_dict("records")
        )

    subjects = sorted(groups)
    cursor = {s: 0 for s in subjects}
    selected = []

    while len(selected) < MEDMCQA_N:
        added = False
        for subject in subjects:
            idx = cursor[subject]
            if idx < len(groups[subject]) and len(selected) < MEDMCQA_N:
                selected.append(groups[subject][idx])
                cursor[subject] += 1
                added = True
        if not added:
            break

    for i, row in enumerate(selected, start=1):
        row["query_id"] = f"MED{i:03d}"

    return selected


def valid_mmlu_question(question):
    q = clean_text(question)
    if not q:
        return False
    words = q.split()
    return 4 <= len(words) <= 45 and len(q) <= 320


def prepare_mmlu():
    print("\n[2/2] Preparing MMLU selected higher-education/professional subjects...")
    all_rows = []

    for subject_index, subject in enumerate(MMLU_SUBJECTS):
        print(f"  - {subject}")
        ds = load_dataset("cais/mmlu", subject, split="test")

        candidates = []
        seen = set()

        for idx, item in enumerate(ds):
            question = clean_text(item.get("question"))
            if not valid_mmlu_question(question):
                continue

            key = norm_text(question)
            if key in seen:
                continue
            seen.add(key)

            choices = item.get("choices", [])
            answer = item.get("answer")

            candidates.append({
                "source_dataset": "MMLU",
                "domain": "Higher-Education Multidomain",
                "subject": subject,
                "query": question,
                "source_split": "test",
                "source_field": "question",
                "original_id": f"{subject}-test-{idx:04d}",
                "choices": [clean_text(x) for x in choices] if choices else [],
                "answer_index": int(answer) if answer is not None else None,
            })

        if len(candidates) < MMLU_PER_SUBJECT:
            raise RuntimeError(
                f"{subject}: only {len(candidates)} candidates passed the "
                f"filter; need {MMLU_PER_SUBJECT}."
            )

        # Separate deterministic seed per subject.
        rng = random.Random(SEED + subject_index)
        rng.shuffle(candidates)
        all_rows.extend(candidates[:MMLU_PER_SUBJECT])

    all_rows = sorted(all_rows, key=lambda r: (r["subject"], r["original_id"]))

    for i, row in enumerate(all_rows, start=1):
        row["query_id"] = f"MMLU{i:03d}"

    return all_rows


def main():
    med = prepare_medmcqa()
    mmlu = prepare_mmlu()

    save_records(med, "medmcqa_100")
    save_records(mmlu, "mmlu_100")

    combined = med + mmlu
    save_records(combined, "cross_domain_200")

    # Metadata is retained for analysis, but the LLM runner must send ONLY
    # the "query" text to LLM-QTH.
    input_records = [
        {
            "query_id": r["query_id"],
            "source_dataset": r["source_dataset"],
            "domain": r["domain"],
            "subject": r["subject"],
            "query": r["query"],
        }
        for r in combined
    ]
    save_records(input_records, "cross_domain_200_input_only")

    df = pd.DataFrame(combined)

    summary = (
        df.groupby(["source_dataset", "domain"], dropna=False)
        .agg(
            n_queries=("query", "count"),
            unique_queries=("query", "nunique"),
            mean_words=("query", lambda s: round(s.str.split().str.len().mean(), 2)),
        )
        .reset_index()
    )
    summary.to_csv(DATA_DIR / "dataset_summary.csv", index=False)

    subject_summary = (
        df.groupby(["source_dataset", "domain", "subject"], dropna=False)
        .agg(
            n_queries=("query", "count"),
            unique_queries=("query", "nunique"),
            mean_words=("query", lambda s: round(s.str.split().str.len().mean(), 2)),
        )
        .reset_index()
    )
    subject_summary.to_csv(
        DATA_DIR / "dataset_summary_by_subject.csv", index=False
    )

    print("\nDONE")
    print(summary.to_string(index=False))
    print("\nImportant:")
    print("- MedMCQA source pool = train, because validation has too few unique topic_name labels.")
    print("- This does NOT train LLM-QTH; train is only used as an external query-label pool.")
    print("- MMLU input = original test question stem only.")
    print("- The LLM-QTH runner must send ONLY the query text.")
    print("- Manually inspect medmcqa_100.csv and mmlu_100.csv before the final experiment.")


if __name__ == "__main__":
    main()
