import json
import numpy as np
import pandas as pd
from sentence_transformers import SentenceTransformer
from config import RESULTS_DIR

PRED_PATH = RESULTS_DIR / "llm_qth_medmcqa_mmlu_predictions.json"


def flatten(row):
    vals = []
    for level in ("basic", "intermediate", "advanced"):
        x = row.get(level, [])
        if isinstance(x, list):
            vals.extend(str(v).strip() for v in x if str(v).strip())
    return " ".join(vals)


def hierarchy_quality(row):
    levels, topics = [], []
    for level in ("basic", "intermediate", "advanced"):
        x = row.get(level, [])
        if not isinstance(x, list):
            x = []
        x = [str(v).strip() for v in x if str(v).strip()]
        levels.append(x)
        topics.extend(x)

    if not topics:
        return 0.0

    presence = sum(bool(x) for x in levels) / 3
    progression = (0.5 if levels[0] and levels[1] else 0) + \
                  (0.5 if levels[1] and levels[2] else 0)
    norm = [" ".join(t.lower().split()) for t in topics]
    diversity = len(set(norm)) / len(norm)
    return 0.30 * presence + 0.30 * progression + 0.40 * diversity


def summarize(g):
    return pd.Series({
        "n": len(g),
        "semantic_similarity_mean": g.semantic_similarity.mean(),
        "semantic_similarity_sd": g.semantic_similarity.std(ddof=1),
        "topic_drift_mean": g.topic_drift.mean(),
        "topic_drift_sd": g.topic_drift.std(ddof=1),
        "hierarchy_quality_mean": g.hierarchy_quality.mean(),
        "hierarchy_quality_sd": g.hierarchy_quality.std(ddof=1),
    })


def main():
    with open(PRED_PATH, "r", encoding="utf-8") as f:
        rows = [r for r in json.load(f) if r.get("status") == "ok"]

    if not rows:
        raise RuntimeError("No successful predictions.")

    model = SentenceTransformer("all-MiniLM-L6-v2")
    q = [r["query"] for r in rows]
    h = [flatten(r) for r in rows]

    qe = model.encode(q, normalize_embeddings=True, show_progress_bar=True)
    he = model.encode(h, normalize_embeddings=True, show_progress_bar=True)
    sims = np.sum(qe * he, axis=1)

    out = []
    for r, sim in zip(rows, sims):
        sim = float(sim)
        out.append({
            "query_id": r["query_id"],
            "source_dataset": r["source_dataset"],
            "domain": r["domain"],
            "subject": r["subject"],
            "query": r["query"],
            "semantic_similarity": sim,
            "topic_drift": float(np.clip(1 - sim, 0, 1)),
            "hierarchy_quality": float(hierarchy_quality(r)),
        })

    df = pd.DataFrame(out)
    df.to_csv(RESULTS_DIR / "cross_domain_per_query_metrics.csv", index=False)

    summary = (
        df.groupby(["source_dataset", "domain"], dropna=False)
          .apply(summarize, include_groups=False)
          .reset_index()
    )
    overall = summarize(df).to_dict()
    overall.update({"source_dataset": "COMBINED", "domain": "Cross-domain overall"})
    summary = pd.concat([summary, pd.DataFrame([overall])], ignore_index=True)
    summary.to_csv(RESULTS_DIR / "cross_domain_summary.csv", index=False)

    subject_summary = (
        df.groupby(["source_dataset", "domain", "subject"], dropna=False)
          .apply(summarize, include_groups=False)
          .reset_index()
    )
    subject_summary.to_csv(
        RESULTS_DIR / "cross_domain_subject_summary.csv", index=False
    )

    print(summary.to_string(index=False))


if __name__ == "__main__":
    main()
