import json
import os
import re
import time
import pandas as pd
from dotenv import load_dotenv
from groq import Groq
from tqdm import tqdm
from config import (
    DATA_DIR, RESULTS_DIR, DEFAULT_MODEL, TEMPERATURE,
    SLEEP_SECONDS, MAX_QUERY_CHARS, SYSTEM_PROMPT, USER_TEMPLATE
)

load_dotenv()
API_KEY = os.getenv("GROQ_API_KEY")
MODEL = os.getenv("GROQ_MODEL", DEFAULT_MODEL)

if not API_KEY:
    raise RuntimeError("Missing GROQ_API_KEY in .env")

client = Groq(api_key=API_KEY)

INPUT_PATH = DATA_DIR / "cross_domain_200_input_only.json"
OUT_JSON = RESULTS_DIR / "llm_qth_medmcqa_mmlu_predictions.json"
OUT_CSV = RESULTS_DIR / "llm_qth_medmcqa_mmlu_predictions.csv"


def parse_json_response(text):
    text = (text or "").strip()
    try:
        obj = json.loads(text)
    except Exception:
        m = re.search(r"\{.*\}", text, flags=re.S)
        if not m:
            raise ValueError("No JSON object found.")
        obj = json.loads(m.group(0))

    out = {}
    for level in ("basic", "intermediate", "advanced"):
        vals = obj.get(level, [])
        if isinstance(vals, str):
            vals = [vals]
        if not isinstance(vals, list):
            vals = []
        out[level] = [str(v).strip() for v in vals if str(v).strip()]
    return out


def save(rows):
    with open(OUT_JSON, "w", encoding="utf-8") as f:
        json.dump(rows, f, indent=2, ensure_ascii=False)
    pd.DataFrame(rows).to_csv(OUT_CSV, index=False, encoding="utf-8")


def main():
    with open(INPUT_PATH, "r", encoding="utf-8") as f:
        inputs = json.load(f)

    rows = []
    if OUT_JSON.exists():
        with open(OUT_JSON, "r", encoding="utf-8") as f:
            rows = json.load(f)

    done = {r["query_id"] for r in rows}

    for item in tqdm(inputs, desc="LLM-QTH"):
        if item["query_id"] in done:
            continue

        # CRITICAL: only query text is passed to LLM-QTH.
        query = item["query"][:MAX_QUERY_CHARS]

        record = dict(item)
        record["model"] = MODEL
        record["temperature"] = TEMPERATURE

        try:
            response = client.chat.completions.create(
                model=MODEL,
                temperature=TEMPERATURE,
                messages=[
                    {"role": "system", "content": SYSTEM_PROMPT},
                    {"role": "user", "content": USER_TEMPLATE.format(query=query)},
                ],
            )
            raw = response.choices[0].message.content
            record.update(parse_json_response(raw))
            record["raw_response"] = raw
            record["status"] = "ok"
        except Exception as e:
            record.update({
                "basic": [],
                "intermediate": [],
                "advanced": [],
                "raw_response": "",
                "status": "error",
                "error": repr(e),
            })

        rows.append(record)
        save(rows)
        time.sleep(SLEEP_SECONDS)

    print(f"Saved: {OUT_JSON}")
    print(f"Saved: {OUT_CSV}")


if __name__ == "__main__":
    main()
