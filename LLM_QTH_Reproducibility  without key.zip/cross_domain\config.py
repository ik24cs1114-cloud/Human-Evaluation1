from pathlib import Path

ROOT = Path(__file__).resolve().parent
DATA_DIR = ROOT / "data"
RESULTS_DIR = ROOT / "results"
DATA_DIR.mkdir(exist_ok=True)
RESULTS_DIR.mkdir(exist_ok=True)

SEED = 42
MEDMCQA_N = 100
MMLU_PER_SUBJECT = 10

# MMLU subjects chosen to broaden the validation beyond the paper's
# computing/engineering-heavy primary evaluation and beyond medicine.
MMLU_SUBJECTS = [
    "abstract_algebra",
    "college_biology",
    "college_chemistry",
    "college_physics",
    "econometrics",
    "business_ethics",
    "philosophy",
    "professional_law",
    "international_law",
    "world_religions",
]

DEFAULT_MODEL = "openai/gpt-oss-20b"
TEMPERATURE = 0.3
SLEEP_SECONDS = 2.0
MAX_QUERY_CHARS = 400

# IMPORTANT:
# Replace this with the exact original LLM-QTH prompt from your main experiment
# if your original wording differs. Do not make domain-specific prompts.
SYSTEM_PROMPT = """
You are an educational topic-hierarchy generator.
Given a short educational query, generate a pedagogically ordered three-level
topic hierarchy.

Basic: foundational concepts requiring little prior knowledge.
Intermediate: concepts that build on the basic level and involve mechanisms,
relationships, application, or analysis.
Advanced: concepts that depend on earlier levels and involve deeper abstraction,
integration, optimization, design, or research-oriented understanding.

Requirements:
1. Every topic must be relevant to the query.
2. Topics must progress from Basic to Intermediate to Advanced.
3. Avoid duplicate or near-duplicate topics.
4. Return ONLY valid JSON with exactly these keys:
   "basic", "intermediate", "advanced".
5. Each key must map to a list of concise topic strings.
""".strip()

USER_TEMPLATE = 'Educational query: "{query}"'
