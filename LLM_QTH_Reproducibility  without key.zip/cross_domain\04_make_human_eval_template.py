import json
import random
import pandas as pd
from config import RESULTS_DIR, SEED

PRED_PATH = RESULTS_DIR / "llm_qth_medmcqa_mmlu_predictions.json"


def main():
    with open(PRED_PATH, "r", encoding="utf-8") as f:
        rows = [r for r in json.load(f) if r.get("status") == "ok"]

    rng = random.Random(SEED)
    selected = []

    for source in ("MedMCQA", "MMLU"):
        pool = [r for r in rows if r["source_dataset"] == source]
        selected.extend(rng.sample(pool, min(25, len(pool))))

    topic_rows, hierarchy_rows = [], []

    for r in selected:
        for level in ("basic", "intermediate", "advanced"):
            for rank, topic in enumerate(r.get(level, []), start=1):
                topic_rows.append({
                    "query_id": r["query_id"],
                    "source_dataset": r["source_dataset"],
                    "subject": r["subject"],
                    "query": r["query"],
                    "level": level,
                    "rank_within_level": rank,
                    "topic": topic,
                    "annotator_id": "",
                    "topic_relevance_0_3": "",
                })

        hierarchy_rows.append({
            "query_id": r["query_id"],
            "source_dataset": r["source_dataset"],
            "subject": r["subject"],
            "query": r["query"],
            "basic": " | ".join(r.get("basic", [])),
            "intermediate": " | ".join(r.get("intermediate", [])),
            "advanced": " | ".join(r.get("advanced", [])),
            "annotator_id": "",
            "coherence_0_3": "",
            "level_appropriateness_0_3": "",
            "progression_0_3": "",
            "non_redundancy_0_3": "",
        })

    pd.DataFrame(topic_rows).to_csv(
        RESULTS_DIR / "human_topic_relevance_template.csv", index=False
    )
    pd.DataFrame(hierarchy_rows).to_csv(
        RESULTS_DIR / "human_hierarchy_template.csv", index=False
    )
    print(f"Prepared {len(selected)} hierarchy cases for human evaluation.")


if __name__ == "__main__":
    main()
