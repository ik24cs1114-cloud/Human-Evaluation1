﻿import argparse
from pathlib import Path
import pandas as pd

def prepare_file(src, out_dir, annotator_id, kind):
    if not src.exists():
        raise FileNotFoundError(f"Missing template: {src}")

    df = pd.read_csv(src)

    if "annotator_id" not in df.columns:
        df["annotator_id"] = ""

    df["annotator_id"] = annotator_id

    # Keep all rating columns blank
    for col in df.columns:
        if col.endswith("_0_3"):
            df[col] = ""

    out_path = out_dir / f"{annotator_id}_{kind}.csv"
    df.to_csv(out_path, index=False, encoding="utf-8-sig")

    print(f"Created: {out_path}")
    return len(df)

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--annotators", type=int, default=3)
    args = parser.parse_args()

    root = Path(__file__).resolve().parent

    results_dir = root / "results"
    output_dir = root / "human_evaluation"
    output_dir.mkdir(exist_ok=True)

    topic_template = results_dir / "human_topic_relevance_template.csv"
    hierarchy_template = results_dir / "human_hierarchy_template.csv"

    print("Checking templates...")

    if not topic_template.exists():
        raise FileNotFoundError(topic_template)

    if not hierarchy_template.exists():
        raise FileNotFoundError(hierarchy_template)

    for i in range(1, args.annotators + 1):
        aid = f"A{i}"

        prepare_file(
            topic_template,
            output_dir,
            aid,
            "topic_relevance"
        )

        prepare_file(
            hierarchy_template,
            output_dir,
            aid,
            "hierarchy"
        )

    print("\nHuman evaluation files prepared successfully.")

if __name__ == "__main__":
    main()
